package br.com.luanhroliveira.interfaces;

import javax.swing.*;

public interface CadVeiculoInterface {
    JButton btLimpar();
    JButton btSalvar();
    JButton btSair();
}
