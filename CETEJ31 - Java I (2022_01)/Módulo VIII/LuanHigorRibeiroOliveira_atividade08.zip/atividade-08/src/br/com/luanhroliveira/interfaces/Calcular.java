package br.com.luanhroliveira.interfaces;

public interface Calcular {
    int calcular();
}
