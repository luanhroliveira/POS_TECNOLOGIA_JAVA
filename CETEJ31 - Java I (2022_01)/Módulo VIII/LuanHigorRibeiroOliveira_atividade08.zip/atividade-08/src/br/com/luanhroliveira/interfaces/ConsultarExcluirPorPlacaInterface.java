package br.com.luanhroliveira.interfaces;

import javax.swing.*;

public interface ConsultarExcluirPorPlacaInterface {

    JButton btConsultar();

    JButton btExcluir();

    JButton btSair();

}
