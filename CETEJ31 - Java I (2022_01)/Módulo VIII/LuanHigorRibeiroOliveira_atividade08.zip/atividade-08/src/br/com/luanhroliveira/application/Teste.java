package br.com.luanhroliveira.application;

import br.com.luanhroliveira.modal.PrincipalPanel;
import br.com.luanhroliveira.services.VeiculoService;

public class Teste {

    public static void main(String[] args) {
        PrincipalPanel principalPanel = new PrincipalPanel();
        principalPanel.loadPanel();
    }

}
