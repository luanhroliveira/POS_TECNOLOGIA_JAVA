package br.com.luanhroliveira.entity.enums;

public enum VeiculoType {
    PASSEIO, CARGA
}
