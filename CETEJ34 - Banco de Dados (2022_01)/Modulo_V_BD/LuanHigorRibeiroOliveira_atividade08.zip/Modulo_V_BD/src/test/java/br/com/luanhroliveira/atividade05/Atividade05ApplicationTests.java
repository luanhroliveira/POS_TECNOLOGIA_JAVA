package br.com.luanhroliveira.atividade05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade05ApplicationTests {

    @Test
    void contextLoads() {
    }

}
